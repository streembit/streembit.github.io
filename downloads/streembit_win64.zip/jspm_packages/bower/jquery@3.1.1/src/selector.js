/* */ 
"format global";
define( [ "./selector-sizzle" ], function() {
	"use strict";
} );
