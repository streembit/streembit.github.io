/* */ 
module.exports = System._nodeRequire ? System._nodeRequire('path') : require('path-browserify');