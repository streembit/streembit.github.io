define(["github:makeusabrew/bootbox@4.4.0/bootbox.js"], function(main) {
  return main;
});