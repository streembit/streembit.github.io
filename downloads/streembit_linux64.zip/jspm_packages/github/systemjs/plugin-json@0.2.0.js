define(["github:systemjs/plugin-json@0.2.0/json"], function(main) {
  return main;
});